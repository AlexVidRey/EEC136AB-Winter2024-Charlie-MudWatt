/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

// CHAR LCD CODE CREDIT: *Char LCD Module credit: MotooTanaka (2021) CharLCD Sample for PSoC 6 (CY8CKIT-062-BLE) [Source Code] https://community.infineon.com/t5/Code-Examples/CharLCD-Sample-for-PSoC-6-CY8CKIT-062-BLE/m-p/268325#M1017
// RTC CREDIT: PSOC CREATOR RTC CODE EXAMPLE 

#include "project.h"
#include "stdio.h"
#include "tty_utils.h"
#include "clcd.h"
#include "func_list.h"
#include "stdlib.h"
#include <math.h>
#include <string.h>
#include "RTC.h"

#define TICK_INTERVAL       (1u)    /* seconds or minutes interval. The range should be 1-59 */
#define USE_SECONDS         (0u)    /* set to one to use, set to zero to not use */
#define USE_MINUTES         (1u)    /* use seconds OR minutes, not both  */
#define MAX_ATTEMPTS        (500u)  /* Maximum number of attempts for RTC operation */ 
#define INIT_DELAY          (5u)    /* delay 5 milliseconds before trying again */

/* The interrupt status variable */
static uint32_t alarmFlag = 0u;

cy_stc_rtc_alarm_t alarmConfig = 
{
    .sec            = RTC_INITIAL_DATE_SEC,
    .secEn          = CY_RTC_ALARM_DISABLE,
    .min            = RTC_INITIAL_DATE_MIN,
    .minEn          = CY_RTC_ALARM_DISABLE,
    .hour           = RTC_INITIAL_DATE_HOUR,
    .hourEn         = CY_RTC_ALARM_DISABLE,
    .dayOfWeek      = RTC_INITIAL_DATE_DOW,
    .dayOfWeekEn    = CY_RTC_ALARM_DISABLE,
    .date           = RTC_INITIAL_DATE_DOM,
    .dateEn         = CY_RTC_ALARM_DISABLE,
    .month          = RTC_INITIAL_DATE_MONTH,
    .monthEn        = CY_RTC_ALARM_DISABLE,
    .almEn          = CY_RTC_ALARM_ENABLE
};

cy_en_rtc_status_t RtcInit(void);
cy_en_rtc_status_t RtcAlarmConfig(void);
void RtcInterruptHandler(void);
void RtcStepAlarm(void);

void do_help(void) ;
void do_clear(void) ;
void do_write(void) ;
void do_SetDDRAddr(void) ;
void do_SetCGRAMAddr(void) ;
void do_Command(void) ;
void do_print(void) ;
void do_pos(void) ;

f_list_type main_func_list[] = {
    { "help",    do_help,          "show help message"   },
    { "clear",   do_clear,         "Clear LCD"           },
    { "write",   do_write,         "Write data to LCD"   },
    { "print",   do_print,         "Write string to LCD" },
    { "ddr",     do_SetDDRAddr,    "Set DDR Address"     },
    { "cg",      do_SetCGRAMAddr,  "Set CG RAM Address"  },
    { "command", do_Command,       "send instruction"    },
    { "pos",     do_pos,           "pos line col"        },
    {     0,     0,                0} /* list terminator */
} ;

    void Opamp_1_Start() ;
    __STATIC_INLINE void Opamp_1_Init(void);
    __STATIC_INLINE void Opamp_1_Enable(void);
    __STATIC_INLINE void Opamp_1_SetPower(cy_en_ctb_power_t);   
    cy_en_rtc_status_t RtcInit(void)
{
    uint32_t attempts = MAX_ATTEMPTS;
    cy_en_rtc_status_t result;
    
    /* Setting the time and date can fail. For example the RTC might be busy.
       Check the result and try again, if necessary.  */
    do
    {
        result = Cy_RTC_Init(&RTC_config);
        attempts--;
        
        Cy_SysLib_Delay(INIT_DELAY);
    } while(( result != CY_RTC_SUCCESS) && (attempts != 0u));
    
	return (result);
}
cy_en_rtc_status_t RtcAlarmConfig(void)
{
    uint32_t attempts = MAX_ATTEMPTS;
    cy_en_rtc_status_t result;
    /* 
       Setting the alarm can fail. For example the RTC might be busy. Check the result and try again, if necessary.
    */
    do
	{
		result = Cy_RTC_SetAlarmDateAndTime((cy_stc_rtc_alarm_t const *)&alarmConfig, CY_RTC_ALARM_2);
		attempts--;
        
		Cy_SysLib_Delay(INIT_DELAY);
    } while(( result != CY_RTC_SUCCESS) && (attempts != 0u));
    
	return (result);
}
void RtcInterruptHandler(void)
{
    Cy_RTC_Interrupt(NULL, false);
}
void Cy_RTC_Alarm2Interrupt(void)
{
    /* the interrupt has fired, meaning time expired and the alarm went off */
	alarmFlag = 1u;  
}    



/////////////////////////////////////////////////////////////////////////
 // MAIN CODE //   
/////////////////////////////////////////////////////////////////////////
int main(void)

{
    func_ptr func ;
    uint8_t data ;
    char cmd[32] ;
    tty_init(USE_CM4) ;    
    CLCD_Init() ; // Initialize LCD Screen
    UART_Start(); // Start UART
    RTC_Start(); // Start RTC
    (void) Cy_CTB_OpampInit(Opamp_1_CTB_HW, Opamp_1_OPAMP_NUM, & Opamp_1_opampConfig) ;
    // Variables
    volatile float val;
    volatile float Vout;
    volatile float gain;
    volatile int Vmudwatt;
    volatile int Moisture;
    
    Cy_GPIO_Write(GreenLED_PORT,GreenLED_NUM,0);
    Cy_GPIO_Write(RedLED_PORT,RedLED_NUM,1);
    
    /////// PSOC RTC Example Initialization Code ////////////
     if(RtcInit() != CY_RTC_SUCCESS) 
    {
        /* If operation fails, halt */
        CY_ASSERT(0u);
    }
    else  /* Configures the alarm to enable interrupt */
    {   
        if( (TICK_INTERVAL == 1u) && (USE_MINUTES == 1u))
        {
            alarmConfig.secEn = CY_RTC_ALARM_ENABLE;
        }
        /* Now configure the alarm */
        if(RtcAlarmConfig() != CY_RTC_SUCCESS)
        {
           /* If operation fails, halt */
           CY_ASSERT(0u);
        }
        else
        {
	        /* This CE uses Alarm2, enable that interrupt */
		    Cy_RTC_SetInterruptMask(CY_RTC_INTR_ALARM2);
        }
    }
    ///////// End PSOC RTC Example Code Initializing ////////////
    
    Cy_SysInt_Init(&RTC_RTC_IRQ_cfg, RtcInterruptHandler); // Initialize Interrupt Handler
    NVIC_EnableIRQ(RTC_RTC_IRQ_cfg.intrSrc); // Enable IRQ
    
    __enable_irq(); /* Enable global interrupts. */
    Cy_GPIO_Write(MoistureVCC_PORT, MoistureVCC_NUM, 0); // Keep Moisture sensor off to avoid adding charge to MudWatt
    
    /////////////////////////////////////////////////////
    ////////// MAIN LOOP FOR CIRCUIT FUNCTION ///////////
    /////////////////////////////////////////////////////
    for(;;) 
    {
        if (alarmFlag==1u) {
            //interrupt occurs => reset flag
            alarmFlag=0u;
            //start ADC and OpAmp
            ADC_Start();
            Opamp_1_Start();          
            CyDelay(5000);
            //take readings from ADC
            Cy_SAR_StartConvert(SAR, CY_SAR_START_CONVERT_SINGLE_SHOT);            
            CyDelay(2000);
            val = Cy_SAR_GetResult32(SAR,0);
            Vout = Cy_SAR_CountsTo_mVolts(SAR,0,val);            
            // Turn ON Moisture sensor => take moisture reading => Turn OFF Moisture sensor
            Cy_GPIO_Write(MoistureVCC_PORT, MoistureVCC_NUM, 1);
            CyDelay(1000);
            Cy_SAR_StartConvert(SAR, CY_SAR_START_CONVERT_CONTINUOUS); 
            CyDelay(1000);
            Moisture = Cy_SAR_GetResult32(SAR,1);
            Cy_GPIO_Write(MoistureVCC_PORT, MoistureVCC_NUM, 0);
            
            gain = 2; //// change based on your noninverting opamp resistors Gain = 1 +RF/R1
            Vmudwatt = Vout/gain ; 
            //clear LCD
            CLCD_Clear();
            CyDelay(1000);
            // print on LCD
            char Vstring[9];
            sprintf(Vstring, "%d", Vmudwatt);       
            char MoistureString[9];
            sprintf(MoistureString, "%d", Moisture);        
            CLCD_PutString("V=");
            CLCD_PutString(Vstring);  
            CLCD_PutString("mV");
            CLCD_PutString(" ");
            //Moisture Low => Red LED ON, print "Soil Dry"
            if (Moisture <10) {
                Cy_GPIO_Write(RedLED_PORT,RedLED_NUM,0);
                CLCD_PutString("Soil Dry");
            }
            // Moisture Good => Red LED OFF, print "Soil Wet"
            else {
                Cy_GPIO_Write(RedLED_PORT,RedLED_NUM,1);
                CLCD_PutString("Soil Wet");
            }
            // Stop ADC and OPAMP to avoid charging/discharging MudWatt
            ADC_Stop();
            Opamp_1_Stop();
            // exit loop
        }
        // wait for another minute to pass
    }

     /////////////////////////////////////////////////////////////////////////////////////////////////////
    
    }

//// FOLLOWING CODE CREDIT: *Char LCD Module credit: MotooTanaka (2021) CharLCD Sample for PSoC 6 (CY8CKIT-062-BLE) [Source Code] https://community.infineon.com/t5/Code-Examples/CharLCD-Sample-for-PSoC-6-CY8CKIT-062-BLE/m-p/268325#M1017

void do_help(void)
{
    show_help(main_func_list) ;
}

void do_clear(void) 
{
    CLCD_Clear() ;
}

void do_write(void) 
{
    int c ;
    sscanf(str, "%*s %x", &c) ;
    CLCD_WriteData(c & 0xFF) ;
}

void do_SetDDRAddr(void) 
{
    int addr ;
    sscanf(str, "%*s %x", &addr) ;
    CLCD_SetDDRAMAddr(addr) ;
}

void do_SetCGRAMAddr(void) 
{
    int addr ;
    sscanf(str, "%*s %x", &addr) ;
    CLCD_SetCGRAMAddr(addr) ;    
}

void do_Command(void) 
{
    int cmd ;
    
    sscanf(str, "%*s %x", &cmd) ;
    CLCD_WriteCommand(cmd) ;
}

void do_print(void)
{
    char buf[81] ;
    sscanf(str, "%*s %s", buf) ;
    CLCD_PutString(buf) ;
}

void do_pos(void)
{
    int line, col ;
    int addr ;
    sscanf(str, "%*s %d %d", &line, &col) ;
    if (line < 1) { 
        line = 1 ;
    }
    if (line > CLCD_NUM_ROWS) {
        line = CLCD_NUM_ROWS ;
    }
    if (col < 1) {
        col = 1 ;
    } 
    if (col > CLCD_NUM_COLS) {
        col = CLCD_NUM_COLS ;
    }
    addr = 0x40 * (line-1) + (col-1) ;
    CLCD_SetDDRAMAddr(addr) ;
}
/////////




/* [] END OF FILE */
